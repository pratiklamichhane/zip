<!DOCTYPE html>
<html lang="en" class="overflow-x-hidden">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Portfolio</title>
    <!--=================================-->
    <!--==== Google font ================-->
    <!--=================================-->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;700&display=swap" rel="stylesheet">
    <!--=================================-->
    <!--==== Main styles ================-->
    <!--=================================-->
    <link rel="stylesheet" href="website/css/styles.css">
</head>
<body class="overflow-x-hidden">
<!--=================================-->
<!--==== Hero =======================-->
<!--=================================-->
<header class="bg-bg pt-10 lg:pt-8 pb-0 lg:pb-16">
    <div class="container">
        <nav class="flex justify-between font-medium">
            <a href="index.html">Pratik L</a>
            <a class="hidden md:inline" href="index.html">Home</a>
            <a class="hidden md:inline" href="work.html">Work</a>
            <a class="hidden md:inline" href="about.html">About</a>
            <a class="hidden md:inline" href="contact.html">Contact</a>
            <button id="mobile_menu_trigger" class="inline md:hidden"><svg width="24" height="15" viewBox="0 0 24 15" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <rect y="0.5" width="24" height="4" fill="#201F27"/>
                    <rect x="12" y="10.5" width="12" height="4" fill="#201F27"/>
                </svg></button>
        </nav>
    </div>
</header>
<div class="bg-bg" style="min-height: auto; display: flex; align-items: center;">
    <div class="container mx-auto pt-16 lg:py-16 grid grid-cols-12 gap-8">
        <div class="col-span-12 md:col-span-12 lg:col-span-12 z-10 relative">
            <h1 class="text-2xl md:text-3xl lg:text-4xl font-medium  mb-12 lg:mb-16 leading-3">Hey , I'm Pratik .
                <br>& I'm Software Engineer<br>
                <p class="text-lg md:text-2xl leading-none">I Develop Websites , Apps and Softwares.</p>
            </h1>
            <div class="grid grid-cols-12 md:grid-cols-8 gap-8 ">
                    <span class="col-span-6 md:col-span-2 lg:col-span-2 relative">Learn more about how I can help<svg class="w-10 absolute top-8 -right-2" fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 38 39">
                        <path d="M1.516 2.033c1.748 0 26.808-4.08 26.808 22.146v11.655" stroke="#000" stroke-width="2" stroke-linecap="round"/>
                        <path d="M36.484 28.841 28.325 37l-8.159-8.159" stroke="#000" stroke-width="2" stroke-linecap="round"/>
                    </svg></span>
                <a href="./contact.html" class="bg-primary hover:bg-transparent col-span-6 md:col-span-2 lg:col-span-2 px-8 py-4 border border-solid border-primary text-white hover:text-primary text-center font-medium rounded-full self-start no-underline transition-colors duration-150">Let’s talk</a>
            </div>
        </div>
    </div>
</div>
<!--=================================-->
<!--==== Introduction ===============-->
<!--=================================-->
<section class="pt-8 lg:pt-20 pb-8 lg:pb-20">
    <div class="container relative py-16 grid grid-cols-12 gap-8">
        <h2 class="text-xl col-span-12 lg:col-span-8">I work with people and brands like you from all around the world to create high quality websites , softwares and applications.</h2>
    </div>
</section>
<!--=================================-->
<!--==== Works ======================-->
<!--=================================-->
<section>
    <!-- The Scrolling Text -->
    <div class="w-full overflow-hidden flex whitespace-nowrap text-3xl lg:text-4xl font-medium uppercase">
        <div class="animate-marquee">
            <span class="ml-10">Featured projects</span>
            <span class="ml-10">Featured projects</span>
            <span class="ml-10">Featured projects</span>
            <span class="ml-10">Featured projects</span>
            <span class="ml-10">Featured projects</span>
        </div>
        <div class="animate-marquee">
            <span class="ml-10">Featured projects</span>
            <span class="ml-10">Featured projects</span>
            <span class="ml-10">Featured projects</span>
            <span class="ml-10">Featured projects</span>
            <span class="ml-10">Featured projects</span>
        </div>
    </div>
    <div class="container grid grid-cols-12 gap-8">
        <div class="col-span-12 md:col-span-6">
            <!-- Project card -->
            <a href="case-study.html" class="block relative mb-16 mt-32">
                <img class="relative -z-10" src="website/images/work_thumbnail_1.jpg" alt="">
                <div class="bg-white w-10/12 pt-4 pr-4 -mt-24">
                    <p>Salonat</p>
                    <h3 class="text-lg lg:text-xl font-medium">Premium furniture eCommerce website</h3>
                </div>
            </a>
            <!-- Project card -->
            <a href="case-study.html" class="block relative mb-16">
                <img class="relative -z-10" src="website/images/work_thumbnail_2.jpg" alt="">
                <div class="bg-white w-10/12 pt-4 pr-4 -mt-24">
                    <p>Zajil</p>
                    <h3 class="text-lg lg:text-xl font-medium">AI-based cold mailing SAAS website</h3>
                </div>
            </a>
        </div>
        <div class="col-span-12 md:col-span-6">
            <!-- Project card -->
            <a href="case-study.html" class="block relative mb-16">
                <img class="relative -z-10" src="website/images/work_thumbnail_3.jpg" alt="">
                <div class="bg-white w-10/12 pt-4 pr-4 -mt-24">
                    <p>JD</p>
                    <h3 class="text-lg lg:text-xl font-medium">Portfolio website for an independent designer</h3>
                </div>
            </a>
            <!-- Project card -->
            <a href="case-study.html" class="block relative mb-16">
                <img class="relative -z-10" src="website/images/work_thumbnail_4.jpg" alt="">
                <div class="bg-white w-10/12 pt-4 pr-4 -mt-24">
                    <p>Bayt Property</p>
                    <h3 class="text-lg lg:text-xl font-medium">Real estate services company website
                    </h3>
                </div>
            </a>
            <div class="flex">
                <a class="flex items-center font-medium ml-auto" href="work.html">
                    See all works
                    <svg class="ml-4" width="11" height="18" viewBox="0 0 11 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path fill-rule="evenodd" clip-rule="evenodd" d="M7.29289 9.00008L0 1.70718L1.41421 0.292969L10.1213 9.00008L1.41421 17.7072L0 16.293L7.29289 9.00008Z" fill="black"/>
                    </svg>
                </a>
            </div>
        </div>
    </div>
</section>
<!--=================================-->
<!--==== Services ===================-->
<!--=================================-->
<section class="pt-16 lg:pt-28 pb-20 lg:pb-40">
    <div class="container relative grid grid-cols-12 gap-8">
        <h2 class="text-xl lg:text-2xl font-medium col-span-12 lg:col-span-6 mb-12">I can help you with</h2>
    </div>
    <div class="container relative grid grid-cols-12 gap-8">
        <!-- Service card -->
        <div class="col-span-12 md:col-span-4">
            <h3 class="text-lg lg:text-xl font-medium mb-4">Web Development</h3>
            <p>Tincidunt elementum, ut tortor suspendisse iaculis placerat diam sociis. Pretium viverra aliquam, libero vitae aliquam tortor</p>
        </div>
        <!-- Service card -->
        <div class="col-span-12 md:col-span-4">
            <h3 class="text-lg lg:text-xl font-medium mb-4">API Development</h3>
            <p>Tincidunt elementum, ut tortor suspendisse iaculis placerat diam sociis. Pretium viverra aliquam, libero vitae aliquam tortor</p>
        </div>
        <!-- Service card -->
        <div class="col-span-12 md:col-span-4">
            <h3 class="text-lg lg:text-xl font-medium mb-4">Designing</h3>
            <p>Tincidunt elementum, ut tortor suspendisse iaculis placerat diam sociis. Pretium viverra aliquam, libero vitae aliquam tortor</p>
        </div>
    </div>
</section>

<!--=================================-->
<!--==== Technologies ===================-->
<!--=================================-->
<section class="pt-16 lg:pt-28 pb-20 lg:pb-40">
    <div class="container relative grid grid-cols-12 gap-8">
        <h2 class="text-xl lg:text-2xl font-medium col-span-12 lg:col-span-6 mb-12">Technologies I Use</h2>
    </div>

</section>

<!--=================================-->
<!--==== Footer =====================-->
<!--=================================-->
<footer class="pt-24 pb-8 bg-bg">
    <div class="container relative grid grid-cols-12 gap-8">
        <div class="col-start-1 lg:col-start-4 col-span-12 lg:col-span-6 flex flex-col justify-center text-center mb-16 lg:mb-24 ">
            <h2 class="text-2xl lg:text-3xl font-medium">Get in touch</h2>
            <a href="./contact.html" class="bg-primary hover:bg-transparent px-16 py-4 border border-solid border-primary text-white hover:text-primary text-center font-medium rounded-full no-underline col-span-2 self-center transition-colors duration-150">Let’s talk</a>
        </div>
        <div class="col-span-12 md:col-span-10 lg:col-span-8 col-start-1 md:col-start-2 lg:col-start-3 flex flex-col md:flex-row items-center justify-start md:justify-between space-y-4 md:space-y-0 text-lg font-medium mb-8">
            <a href="#">Github</a>
            <a href="#">LinkedIn</a>
            <a href="#">Twitter</a>
            <a href="#">Instagram</a>
        </div>
        <div class="col-span-12 flex flex-col md:flex-row items-center md:items-start justify-start md:justify-between space-y-4 md:space-y-0">
            <p>© 2024 All rights reserved.</p>
            <p>Developed by <a class="font-bold" href="/">Pratik Lamichhane</a></p>
        </div>
    </div>
</footer>
<!--=================================-->
<!--==== Mobile Menu ================-->
<!--=================================-->
<div id="mobile_menu" class="w-full bg-primary text-white flex flex-col justify-center text-2xl space-y-4 fixed right-0 translate-x-full top-0  bottom-0 z-50 pl-8 transition-transform duration-500">
    <button id="mobile_menu_close" class="absolute top-10 right-4 flex items-center text-base">close <svg class="ml-4" width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg"><rect x="2.12109" y="0.454041" width="24" height="3" transform="rotate(45 2.12109 0.454041)" fill="#fff"/><rect y="17.4246" width="24" height="3" transform="rotate(-45 0 17.4246)" fill="#fff"/></svg></button>
    <a href="index.html">Home</a>
    <a href="work.html">Work</a>
    <a href="about.html">About</a>
    <a href="contact.html">Contact</a>
</div>

<!--=================================-->
<!--==== Main JS ====================-->
<!--=================================-->
<script src="website/js/scripts.js"></script>
</body>
</html>
<?php /**PATH C:\laragon\www\pratiklamichhane\resources\views/welcome.blade.php ENDPATH**/ ?>